import asyncio
import requests
from motor.motor_asyncio import AsyncIOMotorClient
import aio_pika
import json
from ..core.queue import get_rabbitmq_connection

MONGODB_URL = "mongodb://localhost:27017"  # Update if needed
JOB_SERVICE_URL = "http://localhost:8001/api/v1/jobs/"

async def fetch_user_searches():
    client = AsyncIOMotorClient(MONGODB_URL)
    db = client["job_search"]
    # Get all unique user_ids with search history
    user_ids = await db.search_history.distinct("user_id")
    searches = {}
    for user_id in user_ids:
        history = await db.search_history.find({"user_id": user_id}).sort("created_at", -1).to_list(length=5)
        searches[user_id] = history
    client.close()
    return searches

def fetch_all_jobs():
    resp = requests.get(JOB_SERVICE_URL)
    if resp.status_code == 200:
        return resp.json()
    return []

def find_related_jobs(search_terms, jobs):
    related = []
    for job in jobs:
        for term in search_terms:
            if term.lower() in job["title"].lower() or term.lower() in job["description"].lower():
                related.append(job)
                break
    return related

async def scheduler_loop():
    while True:
        print("[RelatedJobScheduler] Checking for related job notifications...")
        searches = await fetch_user_searches()
        jobs = fetch_all_jobs()
        # Set up RabbitMQ connection for publishing
        connection = await get_rabbitmq_connection()
        channel = await connection.channel()
        queue = await channel.declare_queue("job.related", durable=True)
        for user_id, history in searches.items():
            search_terms = [h["job_name"] for h in history]
            related = find_related_jobs(search_terms, jobs)
            if related:
                print(f"[RelatedJobScheduler] Notifying user {user_id} about jobs: {[j['id'] for j in related]}")
                for job in related:
                    msg = json.dumps({"user_id": user_id, "job": job}).encode()
                    await channel.default_exchange.publish(
                        aio_pika.Message(body=msg),
                        routing_key=queue.name
                    )
            else:
                print(f"[RelatedJobScheduler] No related jobs for user {user_id}")
        await connection.close()
        await asyncio.sleep(30)  # 5 minutes

if __name__ == "__main__":
    asyncio.run(scheduler_loop()) 