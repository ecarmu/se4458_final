import asyncio
import aio_pika
import json
from ..core.queue import get_rabbitmq_connection
from ..services.notification_service import NotificationService
from ..core.database import SessionLocal
from ..schemas.notification import NotificationCreate

class RelatedJobWorker:
    def __init__(self):
        self.db = SessionLocal()
        self.notification_service = NotificationService(self.db)

    def __del__(self):
        self.db.close()

    async def start(self):
        """Start the related job worker"""
        connection = await get_rabbitmq_connection()
        channel = await connection.channel()
        
        # Declare queue
        queue = await channel.declare_queue("job.related")
        
        async with queue.iterator() as queue_iter:
            async for message in queue_iter:
                async with message.process():
                    await self.process_related_job(json.loads(message.body.decode()))

    async def process_related_job(self, data: dict):
        """Process related job notification"""
        user_id = data.get('user_id')
        job = data.get('job')
        if not user_id or not job:
            print('[RelatedJobWorker] Missing user_id or job in data:', data)
            return
        notification = NotificationCreate(
            user_id=user_id,
            type="related_job",
            title="İlgili İş İlanı",
            message=f"'{job.get('title', 'Bir iş')}' başlıklı bir iş ilanı ilginizi çekebilir!",
            data={"job_id": job.get('id')}
        )
        await self.notification_service.create_notification(notification) 