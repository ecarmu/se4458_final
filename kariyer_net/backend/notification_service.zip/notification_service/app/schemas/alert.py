from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime

class AlertBase(BaseModel):
    query: Optional[str] = None
    location: Optional[str] = None
    work_mode: Optional[List[str]] = None
    job_type: Optional[List[str]] = None
    salary_min: Optional[int] = None
    salary_max: Optional[int] = None

class AlertCreate(AlertBase):
    user_id: int

class AlertResponse(AlertBase):
    id: int
    user_id: int
    is_active: bool
    created_at: datetime
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True 