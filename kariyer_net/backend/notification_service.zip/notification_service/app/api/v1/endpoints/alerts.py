from fastapi import APIRouter, Depends, HTTPException
from typing import List
from sqlalchemy.orm import Session
from ....core.database import get_db
from ....schemas.alert import AlertCreate, AlertResponse
from ....services.alert_service import AlertService

router = APIRouter()

def get_alert_service(db: Session = Depends(get_db)) -> AlertService:
    return AlertService(db)

@router.post("/", response_model=AlertResponse)
async def create_job_alert(
    alert: AlertCreate,
    alert_service: AlertService = Depends(get_alert_service)
):
    db_alert = await alert_service.create_alert(alert)
    return db_alert

@router.get("/{user_id}", response_model=List[AlertResponse])
async def get_user_alerts(
    user_id: int,
    alert_service: AlertService = Depends(get_alert_service)
):
    return await alert_service.get_user_alerts(user_id)