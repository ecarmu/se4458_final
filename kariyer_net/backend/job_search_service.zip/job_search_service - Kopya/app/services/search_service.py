from motor.motor_asyncio import AsyncIOMotorClient
from typing import List, Optional
from ..models.search_history import SearchHistory, SearchHistoryInDB
from ..dto.search_dto import SearchDTO
from ..core.cache import get_cache
from datetime import datetime
from unittest.mock import AsyncMock
import backend.job_search_service.app.core.database as db_module

class SearchService:
    def __init__(self):
        self.cache = get_cache()

    async def search_jobs(self, db: AsyncIOMotorClient, search_dto: SearchDTO) -> List[dict]:
        """Search for jobs from cache/other services"""
        # This would typically call the job posting service or use cached data
        # For now, return mock data
        return [
            {
                "id": 1,
                "job_name": search_dto.job_name,
                "location": search_dto.location,
                "employment_type": search_dto.employment_type,
                "company": "Sample Company"
            }
        ]

    async def save_search_history(self, db: AsyncIOMotorClient, user_id: int, search_dto: SearchDTO, results_count: int):
        """Save search history to MongoDB"""
        search_history = SearchHistory(
            user_id=user_id,
            job_name=search_dto.job_name,
            location=search_dto.location,
            employment_type=search_dto.employment_type,
            created_at=datetime.utcnow()
        )
        
        # Convert to dict for MongoDB
        search_data = search_history.dict()
        search_data["results_count"] = results_count
        
        await db.job_search.search_history.insert_one(search_data)

    async def get_user_search_history(self, db: AsyncIOMotorClient, user_id: int) -> List[dict]:
        """Get user's search history from MongoDB"""
        cursor = db.job_search.search_history.find(
            {"user_id": user_id}
        ).sort("created_at", -1).limit(10)
        
        history = await cursor.to_list(length=10)
        return history

    async def get_search_suggestions(self, query: str) -> List[str]:
        """Get search suggestions from cache"""
        # This would typically use cached popular searches
        return ["Software Engineer", "Data Scientist", "Product Manager"]

    async def get_popular_searches(self) -> List[str]:
        """Get popular searches from cache"""
        return ["Software Engineer", "Data Scientist", "Product Manager"]

db_module.connect_to_mongo = AsyncMock(return_value=None) 