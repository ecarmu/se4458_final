from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    app_name: str = "Job Search Service"
    debug: bool = False
    MONGODB_URL: str = "mongodb://localhost:27017"
    REDIS_URL: str = "redis://localhost:6379"
    
    # Job Posting Service
    JOB_POSTING_SERVICE_URL: str = "http://job-posting:8000"
    
    class Config:
        env_file = ".env"

settings = Settings() 